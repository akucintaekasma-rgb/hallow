# Video Sejarah Halloween (Remotion, 1080x1920, 30 fps)

Versi Remotion terkunci di **4.0.504** (semua paket `remotion` dan `@remotion/*` sama persis).

## Cara cepat
1. Pasang Node.js LTS dari https://nodejs.org (versi 18 atau lebih baru).
2. Ekstrak ZIP, buka folder proyek di terminal.
3. `npm install`
4. **Ganti `public/narasi.mp3`** dengan audio narasi aslimu (nama file harus sama). Berkas bawaan hanya audio hening 65 detik agar proyek bisa jalan.
5. `npm run dev` untuk pratinjau di browser.
6. `npm run render` menghasilkan `out/halloween.mp4`.

## Menyesuaikan
- `src/config.ts` -> `AUDIO_OFFSET` (detik) menggeser sinkron subtitle dan gerak terhadap audio.
- `srt/narasi.srt` -> ganti SRT, lalu `npm run captions` membuat ulang `src/captions.ts` (waktu per kata dibagi proporsional jumlah huruf).
- `src/layout.json` -> semua posisi elemen. `npm run check` memeriksa tidak ada kotak yang tumpang tindih dan menulis `docs/koordinat.md`.
- `scripts/make-backgrounds.py` -> memotong ulang background dari `assets_source/papan-background.png` (butuh Python + Pillow, opsional).

## Struktur
- `src/Root.tsx` satu Composition `Halloween`; `src/Video.tsx` merangkai 7 beat (Sequence), transisi, subtitle, audio.
- `src/beats/Beat1..7.tsx` satu komponen per beat.
- `src/components/` stickman (SVG), background, efek, label, subtitle, transisi.

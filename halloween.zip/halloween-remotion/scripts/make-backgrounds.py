# Memotong 7 background dari papan gambar (assets_source/papan-background.png)
# menjadi public/bg/bgN.jpg (tajam, 1920x1060) dan public/bg/bgN_far.jpg (buram, 1080x1920).
# Pakai:  python3 scripts/make-backgrounds.py   (butuh Pillow). Hasilnya sudah disertakan di ZIP.
from pathlib import Path
from PIL import Image, ImageFilter, ImageEnhance

root = Path(__file__).resolve().parent.parent
src = Image.open(root / "assets_source" / "papan-background.png").convert("RGB")
out = root / "public" / "bg"
out.mkdir(parents=True, exist_ok=True)

# kolom x dan baris y papan 3x3 (perkiraan batas tiap panel di gambar 1536x1024)
cols = [(4, 508), (516, 1020), (1028, 1532)]
rows = [(4, 338), (344, 678), (684, 1018)]
# panel 1..7 = baris kiri-ke-kanan, atas-ke-bawah
cells = [(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (0, 2)]
BANNER = 66   # buang label judul di bagian atas panel
INSET = 6

for n, (c, r) in enumerate(cells, start=1):
    x0, x1 = cols[c]
    y0, y1 = rows[r]
    tile = src.crop((x0 + INSET, y0 + BANNER, x1 - INSET, y1 - INSET))
    sharp = tile.resize((1920, 1060), Image.LANCZOS).filter(ImageFilter.UnsharpMask(radius=2, percent=60, threshold=2))
    sharp.save(out / f"bg{n}.jpg", quality=88)
    # latar buram penuh layar vertikal untuk atas dan bawah panggung
    w, h = tile.size
    target = 1080 / 1920
    cw = int(h * target)
    left = (w - cw) // 2
    far = tile.crop((left, 0, left + cw, h)).resize((1080, 1920), Image.LANCZOS)
    far = far.filter(ImageFilter.GaussianBlur(26))
    far = ImageEnhance.Brightness(far).enhance(0.62)
    far.save(out / f"bg{n}_far.jpg", quality=85)
    print("bg", n, "ok")

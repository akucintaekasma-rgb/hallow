// Membuat src/captions.ts dari srt/narasi.srt.
// SRT per frasa -> waktu tiap kata dibagi proporsional dengan jumlah huruf di frasa itu.
import {readFileSync, writeFileSync} from "node:fs";
import {dirname, join} from "node:path";
import {fileURLToPath} from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const raw = readFileSync(join(root, "srt", "narasi.srt"), "utf8").replace(/\r/g, "");

const toSec = (t) => {
  const m = t.trim().match(/^(\d+):(\d+):(\d+)[,.](\d+)$/);
  if (!m) throw new Error("Format waktu SRT salah: " + t);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

const words = [];
for (const block of raw.split(/\n\s*\n/)) {
  const lines = block.trim().split("\n");
  if (lines.length < 3) continue;
  const cue = Number(lines[0]);
  const [a, b] = lines[1].split("-->");
  const start = toSec(a);
  const end = toSec(b);
  const tokens = lines.slice(2).join(" ").split(/\s+/).filter(Boolean);
  const weights = tokens.map((w) => Math.max(1, w.replace(/[^\p{L}\p{N}]/gu, "").length));
  const total = weights.reduce((x, y) => x + y, 0);
  let cursor = start;
  tokens.forEach((text, i) => {
    const dur = ((end - start) * weights[i]) / total;
    words.push({
      text,
      start: Math.round(cursor * 1000) / 1000,
      end: Math.round((cursor + dur) * 1000) / 1000,
      cue,
    });
    cursor += dur;
  });
}

const out =
  "// FILE HASIL GENERATE dari srt/narasi.srt (npm run captions). Waktu dalam detik.\n" +
  "export type CaptionWord = {text: string; start: number; end: number; cue: number};\n\n" +
  "export const captions: CaptionWord[] = " +
  JSON.stringify(words, null, 2) +
  ";\n";
writeFileSync(join(root, "src", "captions.ts"), out);
console.log("OK:", words.length, "kata, kata terakhir selesai di", words[words.length - 1].end, "dtk");

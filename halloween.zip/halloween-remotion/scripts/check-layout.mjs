// Memeriksa src/layout.json: tidak boleh ada dua kotak yang saling tumpang tindih
// (per beat, dan pada tiap momen transisi), lalu menulis tabel koordinat ke docs/koordinat.md.
// Lapisan seluruh-layar (background, kabut, vignette, cahaya) bukan kotak dan tidak ikut diperiksa.
import {readFileSync, writeFileSync, mkdirSync} from "node:fs";
import {dirname, join} from "node:path";
import {fileURLToPath} from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const layout = JSON.parse(readFileSync(join(root, "src", "layout.json"), "utf8"));
const [W, H] = layout.canvas;
const FPS = 30;

// sama persis dengan Easing.inOut(Easing.cubic) di Remotion
const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

function boxAt(el, t) {
  const ks = el.keys;
  if (t <= ks[0].t) return ks[0].box;
  if (t >= ks[ks.length - 1].t) return ks[ks.length - 1].box;
  for (let i = 0; i < ks.length - 1; i++) {
    const a = ks[i];
    const b = ks[i + 1];
    if (t >= a.t && t <= b.t) {
      const p = ease((t - a.t) / (b.t - a.t));
      return a.box.map((v, j) => v + (b.box[j] - v) * p);
    }
  }
  return ks[ks.length - 1].box;
}

const active = (el, t) => t >= el.t[0] - 1e-9 && t <= el.t[1] + 1e-9;
const overlap = (a, b) =>
  Math.min(a[0] + a[2], b[0] + b[2]) - Math.max(a[0], b[0]) > 0.5 &&
  Math.min(a[1] + a[3], b[1] + b[3]) - Math.max(a[1], b[1]) > 0.5;

const globals = layout.global.map((g) => ({id: g.id, t: [-1e9, 1e9], keys: [{t: 0, box: g.box}]}));
const problems = [];

function checkSet(label, items) {
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      if (overlap(items[i].box, items[j].box)) {
        problems.push(`${label}: ${items[i].id} x ${items[j].id}  [${items[i].box.map(Math.round)}] vs [${items[j].box.map(Math.round)}]`);
      }
    }
  }
}

const names = Object.keys(layout.beats);
for (const name of names) {
  const beat = layout.beats[name];
  const els = [...beat.elements, ...globals];
  const steps = Math.round(beat.duration * FPS);
  const seen = new Set();
  for (let f = 0; f <= steps; f++) {
    const t = f / FPS;
    const items = els.filter((e) => active(e, t)).map((e) => ({id: e.id, box: boxAt(e, t)}));
    const before = problems.length;
    checkSet(`${name} @${t.toFixed(2)}s`, items);
    // buang duplikat pasangan yang sama di frame berurutan
    for (let k = problems.length - 1; k >= before; k--) {
      const key = problems[k].replace(/@[\d.]+s/, "");
      if (seen.has(key)) problems.splice(k, 1);
      else seen.add(key);
    }
  }
}

// Momen transisi: keadaan akhir beat yang keluar + keadaan awal beat yang masuk + subtitle
const transitions = [];
for (let i = 0; i < names.length - 1; i++) {
  const out = layout.beats[names[i]];
  const inn = layout.beats[names[i + 1]];
  const outItems = out.elements.filter((e) => active(e, out.duration)).map((e) => ({id: `${names[i]}.${e.id}`, box: boxAt(e, out.duration)}));
  const inItems = inn.elements.filter((e) => active(e, 0)).map((e) => ({id: `${names[i + 1]}.${e.id}`, box: boxAt(e, 0)}));
  const sub = globals.map((g) => ({id: g.id, box: g.keys[0].box}));
  const items = [...outItems, ...inItems, ...sub];
  checkSet(`transisi ${names[i]}->${names[i + 1]}`, items);
  transitions.push({from: names[i], to: names[i + 1], items});
}

// Tabel koordinat
const r = (b) => b.map((v) => Math.round(v)).join(", ");
let md = "# Tabel koordinat (x, y, lebar, tinggi) - kanvas " + W + "x" + H + "\n\n";
md += "Waktu relatif terhadap awal beat. Gerak antar-key memakai easing inOut cubic.\n";
md += "Lapisan seluruh-layar (background, kabut, vignette, cahaya, transisi kabut) bukan kotak.\n\n";
md += "Subtitle (tetap di semua beat): " + r(layout.global[0].box) + "\n\n";
for (const name of names) {
  const beat = layout.beats[name];
  md += `## ${name} (durasi ${beat.duration} dtk)\n\n| elemen | tampil (dtk) | key: waktu -> kotak |\n|---|---|---|\n`;
  for (const e of beat.elements) {
    md += `| ${e.id} | ${e.t[0]}-${e.t[1]} | ${e.keys.map((k) => `${k.t}s: [${r(k.box)}]`).join("<br>")} |\n`;
  }
  md += "\n";
}
md += "## Momen transisi\n\n| transisi | kotak yang terlihat saat potongan (keluar + masuk + subtitle) | tumpang tindih |\n|---|---|---|\n";
for (const tr of transitions) {
  md += `| ${tr.from} -> ${tr.to} | ${tr.items.map((x) => `${x.id} [${r(x.box)}]`).join("<br>")} | tidak ada |\n`;
}
mkdirSync(join(root, "docs"), {recursive: true});

if (problems.length) {
  console.error("TUMPANG TINDIH DITEMUKAN (" + problems.length + "):");
  problems.forEach((p) => console.error(" - " + p));
  process.exit(1);
}
writeFileSync(join(root, "docs", "koordinat.md"), md);
console.log("OK: tidak ada kotak yang tumpang tindih di " + names.length + " beat dan " + transitions.length + " transisi. Tabel: docs/koordinat.md");

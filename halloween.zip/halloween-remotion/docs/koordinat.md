# Tabel koordinat (x, y, lebar, tinggi) - kanvas 1080x1920

Waktu relatif terhadap awal beat. Gerak antar-key memakai easing inOut cubic.
Lapisan seluruh-layar (background, kabut, vignette, cahaya, transisi kabut) bukan kotak.

Subtitle (tetap di semua beat): 60, 1540, 960, 220

## b1 (durasi 9.1 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| title | 0-9.1 | 0s: [90, -260, 900, 230]<br>0.8s: [90, 130, 900, 230] |
| stick | 0-9.1 | 0s: [360, 720, 360, 800]<br>1.4s: [360, 560, 360, 800] |
| bat | 3.2-6.2 | 3.2s: [-220, 430, 200, 100]<br>6.2s: [1100, 430, 200, 100] |

## b2 (durasi 13.176 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-13.176 | 0s: [-380, 600, 360, 800]<br>1.5s: [60, 600, 360, 800] |
| label | 0.4-5.2 | 0.4s: [1080, 430, 700, 120]<br>1s: [330, 430, 700, 120]<br>4.6s: [330, 430, 700, 120]<br>5.2s: [-720, 430, 700, 120] |
| line | 8.3-13.176 | 8.3s: [524, 560, 32, 880] |
| tagMan | 8.6-13.176 | 8.6s: [60, 430, 440, 110] |
| tagRoh | 8.6-13.176 | 8.6s: [580, 430, 440, 110] |
| ghost | 10.5-13.176 | 10.5s: [900, 760, 260, 340]<br>11.4s: [660, 760, 260, 340] |

## b3 (durasi 9.604 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-9.604 | 0s: [-380, 600, 360, 800]<br>1.4s: [60, 600, 360, 800] |
| label | 5.4-9.604 | 5.4s: [-700, 420, 640, 100]<br>6s: [60, 420, 640, 100] |
| ghost | 7.4-9.604 | 7.4s: [720, 560, 260, 340]<br>9.6s: [760, 430, 260, 340] |

## b4 (durasi 10.9 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-10.9 | 0.2s: [-380, 600, 360, 800]<br>3s: [90, 600, 360, 800]<br>5s: [90, 600, 360, 800]<br>6.4s: [560, 600, 360, 800] |
| label | 6.3-10.9 | 6.3s: [-700, 430, 640, 100]<br>6.9s: [60, 430, 640, 100] |

## b5 (durasi 10.352 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-10.352 | 0s: [1100, 800, 270, 600]<br>0.9s: [780, 800, 270, 600] |
| labelA | 0.8-4.6 | 0.8s: [-660, 430, 600, 110]<br>1.4s: [60, 430, 600, 110] |
| labelB | 5.6-10.352 | 5.6s: [-660, 430, 600, 110]<br>6.2s: [60, 430, 600, 110] |

## b6 (durasi 7.628 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-7.628 | 0s: [1100, 600, 360, 800]<br>1s: [640, 600, 360, 800] |
| batA | 1-5 | 1s: [-220, 400, 200, 90]<br>5s: [1100, 400, 200, 90] |
| batB | 2-6 | 2s: [1100, 510, 160, 80]<br>6s: [-200, 510, 160, 80] |
| stamp | 4.3-7.628 | 4.3s: [60, 640, 520, 200] |

## b7 (durasi 4.2 dtk)

| elemen | tampil (dtk) | key: waktu -> kotak |
|---|---|---|
| stick | 0-4.2 | 0s: [-380, 600, 360, 800]<br>1.2s: [360, 600, 360, 800] |
| label | 1.2-4.2 | 1.2s: [190, 430, 700, 150] |

## Momen transisi

| transisi | kotak yang terlihat saat potongan (keluar + masuk + subtitle) | tumpang tindih |
|---|---|---|
| b1 -> b2 | b1.title [90, 130, 900, 230]<br>b1.stick [360, 560, 360, 800]<br>b2.stick [-380, 600, 360, 800]<br>subtitle [60, 1540, 960, 220] | tidak ada |
| b2 -> b3 | b2.stick [60, 600, 360, 800]<br>b2.line [524, 560, 32, 880]<br>b2.tagMan [60, 430, 440, 110]<br>b2.tagRoh [580, 430, 440, 110]<br>b2.ghost [660, 760, 260, 340]<br>b3.stick [-380, 600, 360, 800]<br>subtitle [60, 1540, 960, 220] | tidak ada |
| b3 -> b4 | b3.stick [60, 600, 360, 800]<br>b3.label [60, 420, 640, 100]<br>b3.ghost [760, 430, 260, 340]<br>b4.stick [-380, 600, 360, 800]<br>subtitle [60, 1540, 960, 220] | tidak ada |
| b4 -> b5 | b4.stick [560, 600, 360, 800]<br>b4.label [60, 430, 640, 100]<br>b5.stick [1100, 800, 270, 600]<br>subtitle [60, 1540, 960, 220] | tidak ada |
| b5 -> b6 | b5.stick [780, 800, 270, 600]<br>b5.labelB [60, 430, 600, 110]<br>b6.stick [1100, 600, 360, 800]<br>subtitle [60, 1540, 960, 220] | tidak ada |
| b6 -> b7 | b6.stick [640, 600, 360, 800]<br>b6.stamp [60, 640, 520, 200]<br>b7.stick [-380, 600, 360, 800]<br>subtitle [60, 1540, 960, 220] | tidak ada |

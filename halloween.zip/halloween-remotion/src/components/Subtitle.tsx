import React from "react";
import {useCurrentFrame} from "remotion";
import {COLORS, FONT} from "../config";
import {SUB_CHUNKS} from "../timeline";

const BOX = {x: 60, y: 1540, w: 960, h: 220};

/**
 * Subtitle kuning-oranye, huruf hitam tebal. Posisi tetap (sama dengan layout.json).
 * Waktu tiap kata datang dari captions.ts (SRT dibagi proporsional jumlah huruf).
 */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const chunk = SUB_CHUNKS.find((c) => frame >= c.fromF && frame < c.toF);
  if (!chunk) return null;

  const lines = [chunk.words.slice(0, chunk.split), chunk.words.slice(chunk.split)].filter((l) => l.length > 0);

  return (
    <div style={{position: "absolute", left: BOX.x, top: BOX.y, width: BOX.w, height: BOX.h}}>
      <div
        style={{
          width: BOX.w - 10,
          height: BOX.h - 10,
          boxSizing: "border-box",
          background: COLORS.subtitle,
          border: `8px solid ${COLORS.ink}`,
          boxShadow: `10px 10px 0 ${COLORS.ink}`,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: FONT,
          fontWeight: 900,
          fontSize: 52,
        }}
      >
        {lines.map((line, li) => (
          <div key={li} style={{height: 80, lineHeight: "80px", display: "flex", justifyContent: "center", whiteSpace: "nowrap"}}>
            {line.map((w, wi) => {
              const spoken = frame >= w.fromF;
              const current = frame >= w.fromF && frame < w.toF;
              return (
                <span
                  key={wi}
                  style={{
                    padding: "0 9px",
                    color: COLORS.ink,
                    opacity: spoken ? 1 : 0.45,
                    background: current ? COLORS.subtitleHit : "transparent",
                  }}
                >
                  {w.text}
                </span>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

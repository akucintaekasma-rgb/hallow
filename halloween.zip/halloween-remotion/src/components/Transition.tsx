import React from "react";
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from "remotion";

const DUR = 30;

/**
 * Transisi sinematik 30 frame. Potongan antar beat terjadi di frame ke-15,
 * saat lapisan paling pekat, jadi pergantian adegan tidak terlihat.
 */
export const Transition: React.FC<{kind: "fog" | "lantern"}> = ({kind}) => {
  const f = useCurrentFrame();
  const env = interpolate(f, [0, DUR / 2, DUR], [0, 1, 0], {easing: Easing.inOut(Easing.quad)});

  if (kind === "lantern") {
    // cahaya lentera membesar dari lentera di beat 5 sampai menutup layar
    const r = interpolate(f, [0, DUR / 2, DUR], [60, 2600, 60], {easing: Easing.inOut(Easing.cubic)});
    return (
      <AbsoluteFill>
        <div
          style={{
            position: "absolute",
            left: 850 - r,
            top: 760 - r,
            width: r * 2,
            height: r * 2,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(255,214,130,1) 0%, rgba(255,150,50,0.97) 45%, rgba(255,120,30,0) 72%)",
            opacity: Math.min(1, env * 1.15),
          }}
        />
      </AbsoluteFill>
    );
  }

  const bands = [0, 1, 2, 3, 4].map((i) => {
    const x = interpolate(f, [0, DUR], [-1600 + i * 120, 500 + i * 80], {easing: Easing.inOut(Easing.cubic)});
    return (
      <div
        key={i}
        style={{
          position: "absolute",
          left: x,
          top: -80 + i * 400,
          width: 1700,
          height: 760,
          background: "radial-gradient(ellipse at center, rgba(176,160,208,0.95) 0%, rgba(176,160,208,0) 70%)",
          opacity: env * 0.9,
        }}
      />
    );
  });

  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: "#140a24", opacity: env * 0.97}} />
      {bands}
    </AbsoluteFill>
  );
};

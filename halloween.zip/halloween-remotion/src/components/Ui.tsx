import React from "react";
import {interpolate, spring} from "remotion";
import {COLORS, FONT, FPS} from "../config";
import {boxAt, isActive, startOfEl} from "../layout";

/** Papan teks krem bergaya perkamen: geser masuk dari layout.json, sedikit membal (spring). */
export const Label: React.FC<{beat: string; id: string; text: string; frame: number; fontSize?: number}> = ({beat, id, text, frame, fontSize = 52}) => {
  const t = frame / FPS;
  if (!isActive(beat, id, t)) return null;
  const b = boxAt(beat, id, t);
  const pop = spring({frame: frame - Math.round(startOfEl(beat, id) * FPS), fps: FPS, config: {damping: 13, stiffness: 150}});
  return (
    <div
      style={{
        position: "absolute",
        left: b.x,
        top: b.y,
        width: b.w,
        height: b.h,
        boxSizing: "border-box",
        paddingRight: 10,
        paddingBottom: 10,
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          boxSizing: "border-box",
          background: COLORS.cream,
          border: `6px solid ${COLORS.ink}`,
          boxShadow: `10px 10px 0 ${COLORS.ink}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: FONT,
          fontWeight: 900,
          fontSize,
          letterSpacing: 2,
          color: "#2b1408",
          whiteSpace: "nowrap",
          transform: `scale(${0.94 + 0.06 * pop})`,
        }}
      >
        {text}
      </div>
    </div>
  );
};

/** Judul pembukaan (hanya beat 1). */
export const Title: React.FC<{frame: number}> = ({frame}) => {
  const t = frame / FPS;
  const b = boxAt("b1", "title", t);
  const pop = spring({frame, fps: FPS, config: {damping: 11, stiffness: 120}});
  const hit = interpolate(pop, [0, 1], [0.92, 1]);
  return (
    <div
      style={{
        position: "absolute",
        left: b.x,
        top: b.y,
        width: b.w,
        height: b.h,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: FONT,
        fontWeight: 900,
        textAlign: "center",
        transform: `scale(${hit})`,
      }}
    >
      <div
        style={{
          height: 84,
          lineHeight: "84px",
          fontSize: 66,
          letterSpacing: 14,
          color: COLORS.cream,
          textShadow: `5px 5px 0 ${COLORS.ink}`,
        }}
      >
        SEJARAH
      </div>
      <div
        style={{
          height: 130,
          lineHeight: "130px",
          fontSize: 118,
          letterSpacing: 2,
          color: COLORS.orange,
          textShadow: `0 0 0 ${COLORS.ink}, 7px 7px 0 ${COLORS.ink}, -3px -3px 0 ${COLORS.ink}, 3px -3px 0 ${COLORS.ink}, -3px 3px 0 ${COLORS.ink}`,
        }}
      >
        HALLOWEEN
      </div>
    </div>
  );
};

/** Stempel merah "31 OKTOBER": jatuh membesar lalu menempel. */
export const Stamp: React.FC<{beat: string; id: string; frame: number; line1: string; line2?: string}> = ({beat, id, frame, line1, line2}) => {
  const t = frame / FPS;
  if (!isActive(beat, id, t)) return null;
  const b = boxAt(beat, id, t);
  const f0 = Math.round(startOfEl(beat, id) * FPS);
  const pop = spring({frame: frame - f0, fps: FPS, config: {damping: 9, stiffness: 220}});
  const sc = interpolate(pop, [0, 1], [1.7, 1]);
  const op = interpolate(frame - f0, [0, 3], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <div style={{position: "absolute", left: b.x, top: b.y, width: b.w, height: b.h, display: "flex", alignItems: "center", justifyContent: "center"}}>
      <div
        style={{
          width: 480,
          height: 160,
          boxSizing: "border-box",
          border: `10px solid ${COLORS.blood}`,
          color: COLORS.blood,
          background: "rgba(239,227,194,0.92)",
          fontFamily: FONT,
          fontWeight: 900,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 60,
          letterSpacing: 3,
          whiteSpace: "nowrap",
          transform: `rotate(-5deg) scale(${sc})`,
          opacity: op,
        }}
      >
        {line2 ? (
          <span>
            <span style={{fontSize: 96}}>{line1}</span> {line2}
          </span>
        ) : (
          line1
        )}
      </div>
    </div>
  );
};

import React from "react";
import {COLORS} from "../config";
import type {Box} from "../layout";

export type Arm = [number, number];

export type StickProps = {
  box: Box;
  frame: number;
  /** 0..1 intensitas langkah kaki */
  walk?: number;
  lean?: number;
  /** sudut lengan: 0 = ke bawah, 90 = ke kanan, 180 = ke atas, -90 = ke kiri */
  armL?: Arm;
  armR?: Arm;
  cloak?: "dark" | "brown";
  /** 0..1.15 skala topeng tengkorak */
  mask?: number;
  basket?: boolean;
  lantern?: boolean;
  /** 0..1, mata merah bila > 0.5 */
  evil?: number;
  smile?: number;
  look?: number;
};

const rad = (d: number) => (d * Math.PI) / 180;
const step = (x: number, y: number, ang: number, len: number) => ({
  x: x + Math.sin(rad(ang)) * len,
  y: y + Math.cos(rad(ang)) * len,
});

export const mixArm = (a: Arm, b: Arm, k: number): Arm => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k];

export const Stickman: React.FC<StickProps> = ({
  box,
  frame,
  walk = 0,
  lean = 0,
  armL = [-10, -6],
  armR = [10, 6],
  cloak = "dark",
  mask = 0,
  basket = false,
  lantern = false,
  evil = 0,
  smile = 0,
  look = 0,
}) => {
  const phase = frame / 6;
  const bob = Math.sin(frame / 14) * 3 * (1 - walk) - Math.abs(Math.sin(phase)) * 8 * walk;
  const sway = Math.sin(frame / 18) * 8 + Math.sin(phase) * 14 * walk;
  const stepL = Math.sin(phase) * 38 * walk;
  const liftL = Math.max(0, Math.cos(phase)) * 20 * walk;
  const stepR = -Math.sin(phase) * 38 * walk;
  const liftR = Math.max(0, -Math.cos(phase)) * 20 * walk;
  const swing = Math.sin(phase) * 22 * walk;

  const fill = cloak === "dark" ? COLORS.cloakDark : COLORS.cloakBrown;
  const shade = cloak === "dark" ? COLORS.cloakDarkShade : COLORS.cloakBrownShade;

  const aL: Arm = [armL[0] - swing, armL[1] - swing];
  const aR: Arm = [armR[0] + swing, armR[1] + swing];
  const shL = {x: 150, y: 252};
  const shR = {x: 210, y: 252};
  const elL = step(shL.x, shL.y, aL[0], 82);
  const haL = step(elL.x, elL.y, aL[1], 76);
  const elR = step(shR.x, shR.y, aR[0], 82);
  const haR = step(elR.x, elR.y, aR[1], 76);

  const blink = frame % 110 < 4 ? 0.1 : 1;
  const eyeH = 36 * blink;
  const exL = 163 + look * 10;
  const exR = 194 + look * 10;
  const eyeColor = evil > 0.5 ? "#ff2a1a" : COLORS.ink;
  const m = Math.max(0, Math.min(1.15, mask));
  const flick = 0.85 + 0.15 * Math.sin(frame * 0.8);

  const arm = (s: {x: number; y: number}, e: {x: number; y: number}, h: {x: number; y: number}) => (
    <>
      <polyline points={`${s.x},${s.y} ${e.x},${e.y} ${h.x},${h.y}`} fill="none" stroke={COLORS.ink} strokeWidth={20} strokeLinecap="round" strokeLinejoin="round" />
      <polyline points={`${s.x},${s.y} ${e.x},${e.y} ${h.x},${h.y}`} fill="none" stroke={fill} strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
    </>
  );

  return (
    <div style={{position: "absolute", left: box.x, top: box.y, width: box.w, height: box.h}}>
      <svg viewBox="0 0 360 800" width="100%" height="100%" style={{overflow: "visible"}}>
        <defs>
          <radialGradient id={`lg-${cloak}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(255,175,60,0.6)" />
            <stop offset="100%" stopColor="rgba(255,175,60,0)" />
          </radialGradient>
        </defs>
        <g transform={`rotate(${lean} 180 640) translate(0 ${bob})`}>
          {/* kaki */}
          <line x1={148} y1={600} x2={148 + stepL} y2={715 - liftL} stroke={COLORS.ink} strokeWidth={9} strokeLinecap="round" />
          <line x1={212} y1={600} x2={212 + stepR} y2={715 - liftR} stroke={COLORS.ink} strokeWidth={9} strokeLinecap="round" />
          <ellipse cx={136 + stepL} cy={728 - liftL} rx={42} ry={22} fill={COLORS.shoe} stroke={COLORS.ink} strokeWidth={6} />
          <ellipse cx={224 + stepR} cy={728 - liftR} rx={42} ry={22} fill={COLORS.shoe} stroke={COLORS.ink} strokeWidth={6} />

          {/* jubah */}
          <path
            d={`M150 225 C125 300, 85 470, ${55 + sway} 610 Q180 650 ${305 + sway} 610 C275 470, 235 300, 210 225 Z`}
            fill={fill}
            stroke={COLORS.ink}
            strokeWidth={8}
            strokeLinejoin="round"
          />
          <path d={`M165 300 Q150 450 ${120 + sway * 0.6} 592`} fill="none" stroke={shade} strokeWidth={5} strokeLinecap="round" />
          <path d={`M195 300 Q210 450 ${240 + sway * 0.6} 592`} fill="none" stroke={shade} strokeWidth={5} strokeLinecap="round" />
          <ellipse cx={180} cy={230} rx={40} ry={14} fill={shade} stroke={COLORS.ink} strokeWidth={5} />
          <circle cx={180} cy={266} r={10} fill="#e8963a" stroke={COLORS.ink} strokeWidth={3} />

          {/* lengan */}
          {arm(shL, elL, haL)}
          {arm(shR, elR, haR)}

          {/* barang di tangan kanan */}
          {basket && (
            <g transform={`translate(${haR.x} ${haR.y})`}>
              <path d="M-38 10 Q0 -48 38 10" fill="none" stroke="#6b4423" strokeWidth={7} strokeLinecap="round" />
              <path d="M-48 10 L48 10 L36 64 L-36 64 Z" fill="#b57a38" stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round" />
              <line x1={-42} y1={30} x2={42} y2={30} stroke="#7d5224" strokeWidth={3} />
              <line x1={-39} y1={48} x2={39} y2={48} stroke="#7d5224" strokeWidth={3} />
              <circle cx={-22} cy={6} r={13} fill="#f28a1c" stroke={COLORS.ink} strokeWidth={3} />
              <circle cx={2} cy={0} r={12} fill="#f2c21c" stroke={COLORS.ink} strokeWidth={3} />
              <circle cx={24} cy={7} r={12} fill="#d94a1c" stroke={COLORS.ink} strokeWidth={3} />
            </g>
          )}
          {lantern && (
            <g transform={`translate(${haR.x} ${haR.y})`}>
              <circle cx={0} cy={70} r={130} fill={`url(#lg-${cloak})`} opacity={flick} />
              <line x1={0} y1={0} x2={0} y2={30} stroke={COLORS.ink} strokeWidth={5} />
              <rect x={-6} y={24} width={12} height={14} fill="#5a6b22" stroke={COLORS.ink} strokeWidth={3} />
              <ellipse cx={0} cy={72} rx={48} ry={40} fill="#f5821f" stroke={COLORS.ink} strokeWidth={5} />
              <path d="M-14 66 L-4 66 L-9 54 Z M14 66 L4 66 L9 54 Z" fill="#ffe27a" stroke={COLORS.ink} strokeWidth={2} />
              <path d="M-24 82 L-12 90 L-4 82 L4 90 L12 82 L24 90 L18 98 L-18 98 Z" fill="#ffe27a" stroke={COLORS.ink} strokeWidth={2} />
            </g>
          )}

          {/* tangan putih */}
          <circle cx={haL.x} cy={haL.y} r={13} fill="#fff" stroke={COLORS.ink} strokeWidth={5} />
          <circle cx={haR.x} cy={haR.y} r={13} fill="#fff" stroke={COLORS.ink} strokeWidth={5} />

          {/* kepala */}
          <circle cx={180} cy={125} r={100} fill="#fff" stroke={COLORS.ink} strokeWidth={8} />
          <line x1={exL} y1={102} x2={exL} y2={102 + eyeH} stroke={eyeColor} strokeWidth={8} strokeLinecap="round" />
          <line x1={exR} y1={102} x2={exR} y2={102 + eyeH} stroke={eyeColor} strokeWidth={8} strokeLinecap="round" />
          {evil > 0.5 && (
            <>
              <line x1={exL - 16} y1={88} x2={exL + 12} y2={98} stroke={COLORS.ink} strokeWidth={6} strokeLinecap="round" />
              <line x1={exR + 16} y1={88} x2={exR - 12} y2={98} stroke={COLORS.ink} strokeWidth={6} strokeLinecap="round" />
            </>
          )}
          <path d={`M${166 + look * 10} 170 Q${180 + look * 10} ${170 + 16 * smile} ${196 + look * 10} 170`} fill="none" stroke={COLORS.ink} strokeWidth={5} strokeLinecap="round" opacity={smile} />

          {/* topeng tengkorak */}
          {m > 0.01 && (
            <g transform={`translate(180 125) scale(${m}) translate(-180 -125)`}>
              <ellipse cx={180} cy={196} rx={50} ry={32} fill="#ebe2c6" stroke={COLORS.ink} strokeWidth={6} />
              <ellipse cx={180} cy={118} rx={86} ry={92} fill="#ebe2c6" stroke={COLORS.ink} strokeWidth={6} />
              <ellipse cx={146} cy={118} rx={25} ry={31} fill={COLORS.ink} />
              <ellipse cx={214} cy={118} rx={25} ry={31} fill={COLORS.ink} />
              <path d="M180 150 L169 174 L191 174 Z" fill={COLORS.ink} />
              <line x1={160} y1={186} x2={160} y2={222} stroke={COLORS.ink} strokeWidth={4} />
              <line x1={180} y1={188} x2={180} y2={226} stroke={COLORS.ink} strokeWidth={4} />
              <line x1={200} y1={186} x2={200} y2={222} stroke={COLORS.ink} strokeWidth={4} />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};

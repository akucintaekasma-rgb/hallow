import React from "react";
import {AbsoluteFill, interpolate} from "remotion";
import {COLORS} from "../config";
import type {Box} from "../layout";

/* ---------- Cahaya (dipasang di dalam Background, koordinat gambar) ---------- */

type GlowProps = {
  frame: number;
  x: number;
  y: number;
  r: number;
  color: string;
  mode?: "pulse" | "flicker" | "ramp";
  period?: number;
  base?: number;
  amp?: number;
  /** frame mulai menyala (mode ramp) */
  from?: number;
};

export const Glow: React.FC<GlowProps> = ({frame, x, y, r, color, mode = "pulse", period = 45, base = 0.75, amp = 0.25, from = 0}) => {
  let o: number;
  if (mode === "flicker") {
    o = base + amp * (0.5 * Math.sin(frame * 0.83) + 0.5 * Math.sin(frame * 0.31 + 2));
  } else if (mode === "ramp") {
    o = interpolate(frame, [from, from + 12], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"}) * (base + amp * Math.sin(frame / period));
  } else {
    o = base + amp * Math.sin(frame / period);
  }
  return (
    <div
      style={{
        position: "absolute",
        left: x - r,
        top: y - r,
        width: r * 2,
        height: r * 2,
        borderRadius: "50%",
        background: `radial-gradient(circle, ${color} 0%, rgba(0,0,0,0) 68%)`,
        opacity: Math.max(0, o),
        mixBlendMode: "screen",
      }}
    />
  );
};

/* ---------- Bara api (acak dengan seed tetap) ---------- */

const lcg = (seed: number) => {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
};

export const Embers: React.FC<{frame: number; cx: number; baseY: number; count?: number}> = ({frame, cx, baseY, count = 16}) => {
  const rnd = lcg(31337);
  const items = Array.from({length: count}, () => ({
    speed: 2 + rnd() * 3,
    phase: rnd() * 600,
    dx: (rnd() - 0.5) * 300,
    wob: rnd() * 6,
    size: 4 + rnd() * 6,
  }));
  return (
    <>
      {items.map((e, i) => {
        const travel = (frame * e.speed + e.phase) % 620;
        const prog = travel / 620;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: cx + e.dx + Math.sin(frame / 20 + e.wob) * 24 * prog,
              top: baseY - travel,
              width: e.size,
              height: e.size,
              borderRadius: "50%",
              background: "#ffb347",
              opacity: (1 - prog) * 0.9,
            }}
          />
        );
      })}
    </>
  );
};

/* ---------- Kabut, vignette ---------- */

export const Fog: React.FC<{frame: number; y?: number; h?: number; opacity?: number}> = ({frame, y = 1180, h = 380, opacity = 0.5}) => {
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: -300 + i * 380 + Math.sin(frame / (70 + i * 25) + i * 2) * 130,
            top: y + (i % 2) * 70,
            width: 1100,
            height: h,
            background: "radial-gradient(ellipse at center, rgba(176,160,208,0.6) 0%, rgba(176,160,208,0) 70%)",
            opacity,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        "radial-gradient(ellipse at 50% 45%, rgba(8,3,20,0) 45%, rgba(8,3,20,0.62) 100%), linear-gradient(to bottom, rgba(8,3,20,0) 72%, rgba(8,3,20,0.7) 100%)",
    }}
  />
);

/* ---------- Kelelawar ---------- */

const WING = "M90 52 C60 20 20 25 2 48 C22 44 30 56 42 64 C52 58 62 66 74 76 C78 66 84 60 90 62 Z";

export const Bat: React.FC<{box: Box; frame: number; flip?: boolean}> = ({box, frame, flip = false}) => {
  const s = 0.35 + 0.65 * Math.abs(Math.sin(frame / 2.6));
  const wings = `translate(0 52) scale(1 ${s}) translate(0 -52)`;
  return (
    <div style={{position: "absolute", left: box.x, top: box.y, width: box.w, height: box.h, transform: flip ? "scaleX(-1)" : undefined}}>
      <svg viewBox="0 0 200 100" width="100%" height="100%" style={{overflow: "visible"}}>
        <g transform={wings}>
          <path d={WING} fill="#14091f" stroke="#3a2559" strokeWidth={3} strokeLinejoin="round" />
        </g>
        <g transform={`translate(200 0) scale(-1 1) ${wings}`}>
          <path d={WING} fill="#14091f" stroke="#3a2559" strokeWidth={3} strokeLinejoin="round" />
        </g>
        <ellipse cx={100} cy={58} rx={13} ry={20} fill="#14091f" stroke="#3a2559" strokeWidth={3} />
        <circle cx={100} cy={36} r={11} fill="#14091f" stroke="#3a2559" strokeWidth={3} />
        <path d="M92 28 L90 14 L98 24 Z M108 28 L110 14 L102 24 Z" fill="#14091f" stroke="#3a2559" strokeWidth={2} />
        <circle cx={96} cy={36} r={2.2} fill="#ff4a2a" />
        <circle cx={104} cy={36} r={2.2} fill="#ff4a2a" />
      </svg>
    </div>
  );
};

/* ---------- Hantu ---------- */

export const Ghost: React.FC<{box: Box; frame: number; opacity?: number}> = ({box, frame, opacity = 0.82}) => {
  const bob = Math.sin(frame / 14) * 10;
  return (
    <div style={{position: "absolute", left: box.x, top: box.y, width: box.w, height: box.h, opacity}}>
      <svg viewBox="0 0 260 340" width="100%" height="100%" style={{overflow: "visible"}}>
        <g transform={`translate(0 ${bob})`}>
          <path
            d="M30 320 L30 120 C30 50 80 14 130 14 C180 14 230 50 230 120 L230 320 Q205 292 180 320 Q155 292 130 320 Q105 292 80 320 Q55 292 30 320 Z"
            fill="#f1ecff"
            stroke={COLORS.ink}
            strokeWidth={7}
            strokeLinejoin="round"
          />
          <ellipse cx={98} cy={118} rx={15} ry={24} fill={COLORS.ink} />
          <ellipse cx={162} cy={118} rx={15} ry={24} fill={COLORS.ink} />
          <ellipse cx={130} cy={186} rx={17} ry={24 + Math.sin(frame / 7) * 4} fill={COLORS.ink} />
        </g>
      </svg>
    </div>
  );
};

import React from "react";
import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame} from "remotion";
import {FPS} from "../config";

export type PanKey = {t: number; x: number};

type Props = {
  /** nomor background 1..7 */
  n: number;
  /** posisi kiri jendela (piksel gambar tajam 1920 lebar) menurut detik di beat */
  pan: PanKey[];
  zoom: [number, number];
  duration: number;
  children?: React.ReactNode;
};

const IMG_W = 1920;
const IMG_H = 1060;
const TOP = 380;

const feather =
  "linear-gradient(to bottom, rgba(0,0,0,0) 0px, #000 110px, #000 950px, rgba(0,0,0,0) 1060px)";

export const Background: React.FC<Props> = ({n, pan, zoom, duration, children}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const x =
    pan.length === 1
      ? pan[0].x
      : interpolate(
          t,
          pan.map((p) => p.t),
          pan.map((p) => p.x),
          {easing: Easing.inOut(Easing.cubic), extrapolateLeft: "clamp", extrapolateRight: "clamp"},
        );
  const z = interpolate(frame, [0, duration * FPS], zoom, {extrapolateLeft: "clamp", extrapolateRight: "clamp"});

  return (
    <AbsoluteFill>
      <Img
        src={staticFile(`bg/bg${n}_far.jpg`)}
        style={{position: "absolute", left: 0, top: 0, width: 1080, height: 1920}}
      />
      <div
        style={{
          position: "absolute",
          left: 0,
          top: TOP,
          width: 1080,
          height: IMG_H,
          overflow: "hidden",
          WebkitMaskImage: feather,
          maskImage: feather,
        }}
      >
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: IMG_W,
            height: IMG_H,
            transformOrigin: `${x + 540}px ${IMG_H / 2}px`,
            transform: `translateX(${-x}px) scale(${z})`,
          }}
        >
          <Img src={staticFile(`bg/bg${n}.jpg`)} style={{position: "absolute", left: 0, top: 0, width: IMG_W, height: IMG_H}} />
          {children}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// FILE HASIL GENERATE dari srt/narasi.srt (npm run captions). Waktu dalam detik.
export type CaptionWord = {text: string; start: number; end: number; cue: number};

export const captions: CaptionWord[] = [
  {
    "text": "Tahukah",
    "start": 0.1,
    "end": 0.731,
    "cue": 1
  },
  {
    "text": "kamu?",
    "start": 0.731,
    "end": 1.092,
    "cue": 1
  },
  {
    "text": "Halloween",
    "start": 1.092,
    "end": 1.904,
    "cue": 1
  },
  {
    "text": "yang",
    "start": 1.904,
    "end": 2.264,
    "cue": 1
  },
  {
    "text": "identik",
    "start": 2.264,
    "end": 2.896,
    "cue": 1
  },
  {
    "text": "dengan",
    "start": 2.896,
    "end": 3.437,
    "cue": 1
  },
  {
    "text": "hantu,",
    "start": 3.437,
    "end": 3.888,
    "cue": 1
  },
  {
    "text": "labu,",
    "start": 3.888,
    "end": 4.248,
    "cue": 1
  },
  {
    "text": "dan",
    "start": 4.248,
    "end": 4.519,
    "cue": 1
  },
  {
    "text": "kostum",
    "start": 4.519,
    "end": 5.06,
    "cue": 1
  },
  {
    "text": "menyeramkan,",
    "start": 5.06,
    "end": 5.846,
    "cue": 2
  },
  {
    "text": "ternyata",
    "start": 5.846,
    "end": 6.418,
    "cue": 2
  },
  {
    "text": "memiliki",
    "start": 6.418,
    "end": 6.99,
    "cue": 2
  },
  {
    "text": "sejarah",
    "start": 6.99,
    "end": 7.491,
    "cue": 2
  },
  {
    "text": "yang",
    "start": 7.491,
    "end": 7.777,
    "cue": 2
  },
  {
    "text": "sangat",
    "start": 7.777,
    "end": 8.206,
    "cue": 2
  },
  {
    "text": "tua.",
    "start": 8.206,
    "end": 8.42,
    "cue": 2
  },
  {
    "text": "Sekitar",
    "start": 9.1,
    "end": 9.654,
    "cue": 3
  },
  {
    "text": "2000",
    "start": 9.654,
    "end": 9.97,
    "cue": 3
  },
  {
    "text": "tahun",
    "start": 9.97,
    "end": 10.366,
    "cue": 3
  },
  {
    "text": "lalu,",
    "start": 10.366,
    "end": 10.683,
    "cue": 3
  },
  {
    "text": "bangsa",
    "start": 10.683,
    "end": 11.157,
    "cue": 3
  },
  {
    "text": "Celtic",
    "start": 11.157,
    "end": 11.632,
    "cue": 3
  },
  {
    "text": "merayakan",
    "start": 11.632,
    "end": 12.344,
    "cue": 3
  },
  {
    "text": "festival",
    "start": 12.344,
    "end": 12.977,
    "cue": 3
  },
  {
    "text": "bernama",
    "start": 12.977,
    "end": 13.531,
    "cue": 3
  },
  {
    "text": "Samhain",
    "start": 13.531,
    "end": 14.085,
    "cue": 3
  },
  {
    "text": "setiap",
    "start": 14.085,
    "end": 14.56,
    "cue": 3
  },
  {
    "text": "akhir",
    "start": 14.56,
    "end": 14.976,
    "cue": 4
  },
  {
    "text": "Oktober.",
    "start": 14.976,
    "end": 15.559,
    "cue": 4
  },
  {
    "text": "Mereka",
    "start": 15.559,
    "end": 16.058,
    "cue": 4
  },
  {
    "text": "percaya",
    "start": 16.058,
    "end": 16.641,
    "cue": 4
  },
  {
    "text": "bahwa",
    "start": 16.641,
    "end": 17.057,
    "cue": 4
  },
  {
    "text": "pada",
    "start": 17.057,
    "end": 17.39,
    "cue": 4
  },
  {
    "text": "malam",
    "start": 17.39,
    "end": 17.806,
    "cue": 4
  },
  {
    "text": "itu,",
    "start": 17.806,
    "end": 18.056,
    "cue": 4
  },
  {
    "text": "batas",
    "start": 18.056,
    "end": 18.472,
    "cue": 4
  },
  {
    "text": "antara",
    "start": 18.472,
    "end": 18.971,
    "cue": 4
  },
  {
    "text": "dunia",
    "start": 18.971,
    "end": 19.388,
    "cue": 4
  },
  {
    "text": "manusia",
    "start": 19.388,
    "end": 19.97,
    "cue": 4
  },
  {
    "text": "dan",
    "start": 19.97,
    "end": 20.22,
    "cue": 4
  },
  {
    "text": "dunia",
    "start": 20.22,
    "end": 20.615,
    "cue": 5
  },
  {
    "text": "roh",
    "start": 20.615,
    "end": 20.853,
    "cue": 5
  },
  {
    "text": "menjadi",
    "start": 20.853,
    "end": 21.406,
    "cue": 5
  },
  {
    "text": "sangat",
    "start": 21.406,
    "end": 21.88,
    "cue": 5
  },
  {
    "text": "tipis.",
    "start": 21.88,
    "end": 22.276,
    "cue": 5
  },
  {
    "text": "Untuk",
    "start": 22.276,
    "end": 22.671,
    "cue": 5
  },
  {
    "text": "melindungi",
    "start": 22.671,
    "end": 23.462,
    "cue": 5
  },
  {
    "text": "diri,",
    "start": 23.462,
    "end": 23.778,
    "cue": 5
  },
  {
    "text": "mereka",
    "start": 23.778,
    "end": 24.252,
    "cue": 5
  },
  {
    "text": "menyalakan",
    "start": 24.252,
    "end": 25.043,
    "cue": 5
  },
  {
    "text": "api",
    "start": 25.043,
    "end": 25.28,
    "cue": 5
  },
  {
    "text": "unggun",
    "start": 25.28,
    "end": 25.696,
    "cue": 6
  },
  {
    "text": "dan",
    "start": 25.696,
    "end": 25.903,
    "cue": 6
  },
  {
    "text": "mengenakan",
    "start": 25.903,
    "end": 26.596,
    "cue": 6
  },
  {
    "text": "kostum",
    "start": 26.596,
    "end": 27.011,
    "cue": 6
  },
  {
    "text": "menyeramkan",
    "start": 27.011,
    "end": 27.773,
    "cue": 6
  },
  {
    "text": "agar",
    "start": 27.773,
    "end": 28.05,
    "cue": 6
  },
  {
    "text": "tidak",
    "start": 28.05,
    "end": 28.396,
    "cue": 6
  },
  {
    "text": "dikenali",
    "start": 28.396,
    "end": 28.95,
    "cue": 6
  },
  {
    "text": "oleh",
    "start": 28.95,
    "end": 29.227,
    "cue": 6
  },
  {
    "text": "roh-roh",
    "start": 29.227,
    "end": 29.643,
    "cue": 6
  },
  {
    "text": "yang",
    "start": 29.643,
    "end": 29.92,
    "cue": 6
  },
  {
    "text": "dipercaya",
    "start": 29.92,
    "end": 30.496,
    "cue": 7
  },
  {
    "text": "berkeliaran.",
    "start": 30.496,
    "end": 31.2,
    "cue": 7
  },
  {
    "text": "Seiring",
    "start": 31.88,
    "end": 32.393,
    "cue": 8
  },
  {
    "text": "waktu,",
    "start": 32.393,
    "end": 32.76,
    "cue": 8
  },
  {
    "text": "tradisi",
    "start": 32.76,
    "end": 33.273,
    "cue": 8
  },
  {
    "text": "ini",
    "start": 33.273,
    "end": 33.493,
    "cue": 8
  },
  {
    "text": "berkembang.",
    "start": 33.493,
    "end": 34.227,
    "cue": 8
  },
  {
    "text": "Muncullah",
    "start": 34.227,
    "end": 34.887,
    "cue": 8
  },
  {
    "text": "kebiasaan",
    "start": 34.887,
    "end": 35.547,
    "cue": 8
  },
  {
    "text": "mengenakan",
    "start": 35.547,
    "end": 36.28,
    "cue": 8
  },
  {
    "text": "kostum",
    "start": 36.28,
    "end": 36.72,
    "cue": 8
  },
  {
    "text": "dan",
    "start": 36.72,
    "end": 36.94,
    "cue": 8
  },
  {
    "text": "meminta",
    "start": 36.94,
    "end": 37.437,
    "cue": 9
  },
  {
    "text": "makanan",
    "start": 37.437,
    "end": 37.934,
    "cue": 9
  },
  {
    "text": "dari",
    "start": 37.934,
    "end": 38.218,
    "cue": 9
  },
  {
    "text": "rumah",
    "start": 38.218,
    "end": 38.573,
    "cue": 9
  },
  {
    "text": "ke",
    "start": 38.573,
    "end": 38.715,
    "cue": 9
  },
  {
    "text": "rumah,",
    "start": 38.715,
    "end": 39.07,
    "cue": 9
  },
  {
    "text": "yang",
    "start": 39.07,
    "end": 39.354,
    "cue": 9
  },
  {
    "text": "kemudian",
    "start": 39.354,
    "end": 39.923,
    "cue": 9
  },
  {
    "text": "ikut",
    "start": 39.923,
    "end": 40.207,
    "cue": 9
  },
  {
    "text": "membentuk",
    "start": 40.207,
    "end": 40.846,
    "cue": 9
  },
  {
    "text": "tradisi",
    "start": 40.846,
    "end": 41.343,
    "cue": 9
  },
  {
    "text": "trick",
    "start": 41.343,
    "end": 41.698,
    "cue": 9
  },
  {
    "text": "or",
    "start": 41.698,
    "end": 41.84,
    "cue": 9
  },
  {
    "text": "treat.",
    "start": 41.84,
    "end": 42.16,
    "cue": 10
  },
  {
    "text": "Awalnya,",
    "start": 42.78,
    "end": 43.325,
    "cue": 11
  },
  {
    "text": "masyarakat",
    "start": 43.325,
    "end": 44.103,
    "cue": 11
  },
  {
    "text": "Irlandia",
    "start": 44.103,
    "end": 44.725,
    "cue": 11
  },
  {
    "text": "mengukir",
    "start": 44.725,
    "end": 45.348,
    "cue": 11
  },
  {
    "text": "wajah",
    "start": 45.348,
    "end": 45.737,
    "cue": 11
  },
  {
    "text": "menyeramkan",
    "start": 45.737,
    "end": 46.593,
    "cue": 11
  },
  {
    "text": "pada",
    "start": 46.593,
    "end": 46.904,
    "cue": 11
  },
  {
    "text": "lobak.",
    "start": 46.904,
    "end": 47.293,
    "cue": 11
  },
  {
    "text": "Ketika",
    "start": 47.293,
    "end": 47.76,
    "cue": 11
  },
  {
    "text": "tradisi",
    "start": 47.76,
    "end": 48.339,
    "cue": 12
  },
  {
    "text": "ini",
    "start": 48.339,
    "end": 48.586,
    "cue": 12
  },
  {
    "text": "sampai",
    "start": 48.586,
    "end": 49.082,
    "cue": 12
  },
  {
    "text": "ke",
    "start": 49.082,
    "end": 49.248,
    "cue": 12
  },
  {
    "text": "Amerika,",
    "start": 49.248,
    "end": 49.826,
    "cue": 12
  },
  {
    "text": "labu",
    "start": 49.826,
    "end": 50.157,
    "cue": 12
  },
  {
    "text": "mulai",
    "start": 50.157,
    "end": 50.57,
    "cue": 12
  },
  {
    "text": "digunakan",
    "start": 50.57,
    "end": 51.314,
    "cue": 12
  },
  {
    "text": "karena",
    "start": 51.314,
    "end": 51.81,
    "cue": 12
  },
  {
    "text": "lebih",
    "start": 51.81,
    "end": 52.223,
    "cue": 12
  },
  {
    "text": "mudah",
    "start": 52.223,
    "end": 52.636,
    "cue": 12
  },
  {
    "text": "diukir.",
    "start": 52.636,
    "end": 53.132,
    "cue": 12
  },
  {
    "text": "Dan",
    "start": 53.132,
    "end": 53.38,
    "cue": 12
  },
  {
    "text": "begitulah",
    "start": 53.38,
    "end": 53.92,
    "cue": 13
  },
  {
    "text": "Halloween",
    "start": 53.92,
    "end": 54.46,
    "cue": 13
  },
  {
    "text": "berkembang",
    "start": 54.46,
    "end": 55.06,
    "cue": 13
  },
  {
    "text": "menjadi",
    "start": 55.06,
    "end": 55.48,
    "cue": 13
  },
  {
    "text": "perayaan",
    "start": 55.48,
    "end": 55.96,
    "cue": 13
  },
  {
    "text": "yang",
    "start": 55.96,
    "end": 56.2,
    "cue": 13
  },
  {
    "text": "kita",
    "start": 56.2,
    "end": 56.44,
    "cue": 13
  },
  {
    "text": "kenal",
    "start": 56.44,
    "end": 56.74,
    "cue": 13
  },
  {
    "text": "sekarang,",
    "start": 56.74,
    "end": 57.22,
    "cue": 13
  },
  {
    "text": "yang",
    "start": 57.22,
    "end": 57.46,
    "cue": 13
  },
  {
    "text": "dirayakan",
    "start": 57.46,
    "end": 58.244,
    "cue": 14
  },
  {
    "text": "setiap",
    "start": 58.244,
    "end": 58.766,
    "cue": 14
  },
  {
    "text": "tanggal",
    "start": 58.766,
    "end": 59.376,
    "cue": 14
  },
  {
    "text": "31",
    "start": 59.376,
    "end": 59.55,
    "cue": 14
  },
  {
    "text": "Oktober.",
    "start": 59.55,
    "end": 60.16,
    "cue": 14
  },
  {
    "text": "Tapi,",
    "start": 60.76,
    "end": 61.038,
    "cue": 15
  },
  {
    "text": "beranikah",
    "start": 61.038,
    "end": 61.664,
    "cue": 15
  },
  {
    "text": "kamu",
    "start": 61.664,
    "end": 61.943,
    "cue": 15
  },
  {
    "text": "keluar",
    "start": 61.943,
    "end": 62.36,
    "cue": 15
  },
  {
    "text": "rumah",
    "start": 62.36,
    "end": 62.708,
    "cue": 15
  },
  {
    "text": "saat",
    "start": 62.708,
    "end": 62.986,
    "cue": 15
  },
  {
    "text": "malam",
    "start": 62.986,
    "end": 63.334,
    "cue": 15
  },
  {
    "text": "Halloween?",
    "start": 63.334,
    "end": 63.96,
    "cue": 15
  }
];

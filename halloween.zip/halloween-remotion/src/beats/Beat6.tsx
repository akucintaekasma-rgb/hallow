import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Bat, Fog, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Stamp} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, isActive, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Beat 6: Halloween modern. Fokus: stempel "31 OKTOBER" jatuh di sisi kiri. */
export const Beat6: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b6", "stick", t);
  const wave = interpolate(t, [2.0, 2.6, 4.0, 4.6], [0, 1, 1, 0], clamp);
  const armL = mixArm([-12, -6], [-150, -165 + Math.sin(frame / 5) * 20], wave);
  const smile = interpolate(t, [1.4, 2.2], [0, 1], clamp);

  return (
    <AbsoluteFill>
      <Background n={6} pan={[{t: 0, x: 0}, {t: 7.628, x: 100}]} zoom={[1, 1.12]} duration={BEATS[5].duration / FPS}>
        <Glow frame={frame} x={240} y={130} r={440} color="rgba(255,225,150,0.6)" period={55} base={0.75} amp={0.25} />
        <Glow frame={frame} x={1060} y={400} r={380} color="rgba(255,170,70,0.45)" mode="flicker" base={0.7} amp={0.25} />
      </Background>
      <Fog frame={frame} y={1200} opacity={0.35} />
      <Stickman box={stick} frame={frame} lantern walk={walkAmount("b6", "stick", t)} armL={armL} armR={[30, 15]} smile={smile} />
      {isActive("b6", "batA", t) && <Bat box={boxAt("b6", "batA", t)} frame={frame} />}
      {isActive("b6", "batB", t) && <Bat box={boxAt("b6", "batB", t)} frame={frame + 7} flip />}
      <Fog frame={frame + 45} y={1340} h={200} opacity={0.25} />
      <Vignette />
      <Stamp beat="b6" id="stamp" frame={frame} line1="31" line2="OKTOBER" />
    </AbsoluteFill>
  );
};

import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Embers, Fog, Ghost, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Label} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, isActive, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const MASK_T = 5.3; // detik, kata "mengenakan kostum"

/** Beat 3: api unggun dan kostum. Fokus: topeng tengkorak menempel di wajah. */
export const Beat3: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b3", "stick", t);
  const toFire = interpolate(t, [1.8, 2.6, 4.8, 5.4], [0, 1, 1, 0], clamp);
  const armR = mixArm([10, 6], [85, 100], toFire);
  const hug = interpolate(t, [MASK_T, MASK_T + 0.7], [0, 1], clamp);
  const armL = mixArm([-12, -6], [-30, 10], hug);
  const mask = spring({frame: Math.max(0, frame - Math.round(MASK_T * FPS)), fps: FPS, config: {damping: 11, stiffness: 160}}) * (t >= MASK_T ? 1 : 0);

  return (
    <AbsoluteFill>
      <Background n={3} pan={[{t: 0, x: 480}, {t: 9.604, x: 440}]} zoom={[1, 1.08]} duration={BEATS[2].duration / FPS}>
        <Glow frame={frame} x={950} y={620} r={460} color="rgba(255,130,40,0.65)" mode="flicker" base={0.8} amp={0.25} />
      </Background>
      <Fog frame={frame} y={1200} opacity={0.4} />
      <Embers frame={frame} cx={540} baseY={1250} />
      <Stickman box={stick} frame={frame} cloak="brown" walk={walkAmount("b3", "stick", t)} armL={armL} armR={armR} mask={mask} look={toFire} />
      {isActive("b3", "ghost", t) && <Ghost box={boxAt("b3", "ghost", t)} frame={frame} opacity={0.7} />}
      <Fog frame={frame + 50} y={1340} h={200} opacity={0.28} />
      <Vignette />
      <Label beat="b3" id="label" text="MENYAMAR DARI ROH" frame={frame} fontSize={44} />
    </AbsoluteFill>
  );
};

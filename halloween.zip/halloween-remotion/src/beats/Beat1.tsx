import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Bat, Fog, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Title} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, isActive, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Beat 1: pembukaan. Fokus: stickman menyapa di bawah bulan; judul turun dari atas. */
export const Beat1: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b1", "stick", t);
  const wave = interpolate(t, [1.4, 2.0, 4.6, 5.2], [0, 1, 1, 0], clamp);
  const armR = mixArm([10, 6], [150, 165 + Math.sin(frame / 5) * 22], wave);
  const smile = interpolate(t, [5, 6], [0, 1], clamp);

  return (
    <AbsoluteFill>
      <Background n={1} pan={[{t: 0, x: 700}, {t: 9.1, x: 840}]} zoom={[1, 1.06]} duration={BEATS[0].duration / FPS}>
        <Glow frame={frame} x={975} y={188} r={420} color="rgba(255,225,150,0.6)" period={50} base={0.75} amp={0.25} />
      </Background>
      <Fog frame={frame} y={1180} opacity={0.5} />
      <Stickman box={stick} frame={frame} walk={walkAmount("b1", "stick", t)} armL={[-12, -6]} armR={armR} smile={smile} />
      {isActive("b1", "bat", t) && <Bat box={boxAt("b1", "bat", t)} frame={frame} />}
      <Fog frame={frame + 40} y={1330} h={220} opacity={0.3} />
      <Vignette />
      <Title frame={frame} />
    </AbsoluteFill>
  );
};

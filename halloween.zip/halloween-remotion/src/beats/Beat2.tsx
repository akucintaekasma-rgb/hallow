import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Fog, Ghost, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Label} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, isActive, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Garis batas dunia manusia / dunia roh: tumbuh dari bawah, lalu menipis di kata "tipis". */
const BoundaryLine: React.FC<{frame: number}> = ({frame}) => {
  const t = frame / FPS;
  if (!isActive("b2", "line", t)) return null;
  const b = boxAt("b2", "line", t);
  const grow = interpolate(t, [8.3, 9.3], [0, 1], clamp);
  const th = interpolate(t, [8.3, 9.3, 12.2, 13.1], [12, 12, 12, 3], clamp);
  const glow = 0.7 + 0.3 * Math.sin(frame / 4);
  return (
    <div style={{position: "absolute", left: b.x, top: b.y, width: b.w, height: b.h}}>
      <div
        style={{
          position: "absolute",
          left: (b.w - th) / 2,
          bottom: 0,
          width: th,
          height: b.h * grow,
          background: "linear-gradient(to top, #ffe9a8, #b8a4ff)",
          boxShadow: `0 0 ${24 * glow}px ${8 * glow}px rgba(190,160,255,0.8)`,
        }}
      />
    </div>
  );
};

/** Beat 2: festival Samhain. Fokus: batas tipis antara dua dunia. */
export const Beat2: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b2", "stick", t);
  const point = interpolate(t, [2.4, 3.2, 7.5, 8.3], [0, 1, 1, 0], clamp);
  const armR = mixArm([10, 6], [85, 95], point);

  return (
    <AbsoluteFill>
      <Background n={2} pan={[{t: 0, x: 400}, {t: 13.176, x: 560}]} zoom={[1, 1.07]} duration={BEATS[1].duration / FPS}>
        <Glow frame={frame} x={960} y={650} r={700} color="rgba(255,150,70,0.35)" period={90} base={0.6} amp={0.2} />
        <Glow frame={frame} x={257} y={777} r={170} color="rgba(255,170,60,0.7)" mode="flicker" base={0.8} amp={0.25} />
        <Glow frame={frame} x={1699} y={707} r={170} color="rgba(255,170,60,0.7)" mode="flicker" base={0.8} amp={0.25} />
      </Background>
      <Fog frame={frame} y={1180} opacity={0.45} />
      <Stickman box={stick} frame={frame} cloak="brown" walk={walkAmount("b2", "stick", t)} armR={armR} look={point} />
      <BoundaryLine frame={frame} />
      {isActive("b2", "ghost", t) && <Ghost box={boxAt("b2", "ghost", t)} frame={frame} opacity={0.75} />}
      <Fog frame={frame + 60} y={1330} h={220} opacity={0.3} />
      <Vignette />
      <Label beat="b2" id="label" text="±2.000 TAHUN LALU" frame={frame} fontSize={46} />
      <Label beat="b2" id="tagMan" text="DUNIA MANUSIA" frame={frame} fontSize={40} />
      <Label beat="b2" id="tagRoh" text="DUNIA ROH" frame={frame} fontSize={40} />
    </AbsoluteFill>
  );
};

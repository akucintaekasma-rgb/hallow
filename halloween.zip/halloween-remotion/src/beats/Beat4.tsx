import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Fog, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Label} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Jendela rumah (koordinat gambar) yang menyala satu per satu: "dari rumah ke rumah". */
const WINDOWS: {x: number; y: number; at: number}[] = [
  {x: 207, y: 228, at: 0.8},
  {x: 546, y: 181, at: 2.0},
  {x: 1150, y: 601, at: 6.2},
  {x: 1697, y: 561, at: 7.2},
];

/** Beat 4: trick or treat. Fokus: stickman berjalan, jendela menyala berurutan. */
export const Beat4: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b4", "stick", t);
  const ask = interpolate(t, [6.0, 6.8], [0, 1], clamp);
  const armR = mixArm([20, 10], [75, 85], ask);

  return (
    <AbsoluteFill>
      <Background n={4} pan={[{t: 0, x: 300}, {t: 10.9, x: 520}]} zoom={[1, 1.06]} duration={BEATS[3].duration / FPS}>
        {WINDOWS.map((w, i) => (
          <Glow key={i} frame={frame} x={w.x} y={w.y} r={230} color="rgba(255,190,80,0.6)" mode="ramp" from={Math.round(w.at * FPS)} period={30} base={0.8} amp={0.2} />
        ))}
      </Background>
      <Fog frame={frame} y={1200} opacity={0.35} />
      <Stickman box={stick} frame={frame} cloak="brown" basket walk={walkAmount("b4", "stick", t)} armR={armR} look={ask} smile={ask} />
      <Fog frame={frame + 30} y={1340} h={200} opacity={0.25} />
      <Vignette />
      <Label beat="b4" id="label" text="RUMAH KE RUMAH" frame={frame} fontSize={48} />
    </AbsoluteFill>
  );
};

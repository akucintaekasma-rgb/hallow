import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Fog, Glow, Vignette} from "../components/Fx";
import {Stickman, mixArm} from "../components/Stickman";
import {Label} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, walkAmount} from "../layout";
import {BEATS} from "../timeline";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Beat 7: penutup. Fokus: pertanyaan "BERANI?", mata stickman memerah, layar menggelap. */
export const Beat7: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b7", "stick", t);
  const ask = interpolate(t, [1.2, 1.9], [0, 1], clamp);
  const armR = mixArm([10, 6], [100, 60], ask);
  const evil = interpolate(t, [2.8, 3.0], [0, 1], clamp);
  const fogA = interpolate(t, [0, 3.5], [0.45, 0.9], clamp);
  const black = interpolate(t, [3.3, 4.1], [0, 1], clamp);

  return (
    <AbsoluteFill>
      <Background n={7} pan={[{t: 0, x: 500}, {t: 4.2, x: 400}]} zoom={[1, 1.1]} duration={BEATS[6].duration / FPS}>
        <Glow frame={frame} x={1000} y={300} r={600} color="rgba(160,140,220,0.3)" period={70} base={0.7} amp={0.2} />
      </Background>
      <Fog frame={frame} y={1100} h={480} opacity={fogA} />
      <Stickman box={stick} frame={frame} walk={walkAmount("b7", "stick", t)} armR={armR} evil={evil} />
      <Fog frame={frame + 70} y={1300} h={260} opacity={fogA * 0.7} />
      <Vignette />
      <Label beat="b7" id="label" text="BERANI?" frame={frame} fontSize={96} />
      <AbsoluteFill style={{background: "#000", opacity: black}} />
    </AbsoluteFill>
  );
};

import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {Background} from "../components/Background";
import {Fog, Glow, Vignette} from "../components/Fx";
import {Stickman} from "../components/Stickman";
import {Label} from "../components/Ui";
import {FPS} from "../config";
import {boxAt, walkAmount} from "../layout";
import {BEATS} from "../timeline";

/**
 * Beat 5: lobak lalu labu. Fokus: kamera bergeser dari lobak (kiri) ke labu (kanan)
 * tepat saat narasi berpindah dari "lobak" ke "labu". Wajah tiap benda menyala bergantian.
 */
export const Beat5: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const stick = boxAt("b5", "stick", t);

  return (
    <AbsoluteFill>
      <Background
        n={5}
        pan={[
          {t: 0, x: 0},
          {t: 4.6, x: 0},
          {t: 5.6, x: 640},
          {t: 10.352, x: 700},
        ]}
        zoom={[1, 1.08]}
        duration={BEATS[4].duration / FPS}
      >
        <Glow frame={frame} x={1552} y={267} r={320} color="rgba(255,170,60,0.7)" period={40} base={0.7} amp={0.2} />
        <Glow frame={frame} x={421} y={500} r={240} color="rgba(255,235,170,0.5)" mode="ramp" from={Math.round(1.5 * FPS)} period={25} base={0.7} amp={0.15} />
        <Glow frame={frame} x={1115} y={590} r={360} color="rgba(255,150,40,0.7)" mode="ramp" from={Math.round(5.8 * FPS)} period={12} base={0.75} amp={0.25} />
      </Background>
      <Fog frame={frame} y={1250} h={300} opacity={0.3} />
      <Stickman box={stick} frame={frame} walk={walkAmount("b5", "stick", t)} armL={[-85, -100]} look={-1} />
      <Vignette />
      <Label beat="b5" id="labelA" text="LOBAK · IRLANDIA" frame={frame} fontSize={44} />
      <Label beat="b5" id="labelB" text="LABU · AMERIKA" frame={frame} fontSize={44} />
    </AbsoluteFill>
  );
};

import React from "react";
import {Composition} from "remotion";
import {FPS, HEIGHT, WIDTH} from "./config";
import {TOTAL_FRAMES} from "./timeline";
import {HalloweenVideo} from "./Video";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Halloween"
      component={HalloweenVideo}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};

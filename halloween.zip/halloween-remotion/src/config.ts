export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/**
 * Geser sinkron dalam DETIK. Nilai positif = subtitle dan semua gerak
 * terjadi lebih lambat dari audio (pakai jika suara terdengar lebih dulu).
 * Nilai negatif = lebih cepat. Contoh: 0.15 atau -0.2.
 */
export const AUDIO_OFFSET = 0;

/** Durasi total = akhir kata terakhir + angka ini (detik). */
export const TAIL_SECONDS = 1;

export const COLORS = {
  ink: "#0d0b12",
  cream: "#efe3c2",
  orange: "#ff8a1f",
  subtitle: "#ffb020",
  subtitleDim: "rgba(13,11,18,0.45)",
  subtitleHit: "#fff4b8",
  cloakDark: "#2a2033",
  cloakDarkShade: "#41325a",
  cloakBrown: "#6a3d20",
  cloakBrownShade: "#8c5732",
  shoe: "#9a5b1f",
  blood: "#b3261e",
};

export const FONT =
  "'Arial Black','Impact','Helvetica Neue',Arial,sans-serif";

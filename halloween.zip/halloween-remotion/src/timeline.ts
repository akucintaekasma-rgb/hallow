import {captions} from "./captions";
import {AUDIO_OFFSET, FPS, TAIL_SECONDS} from "./config";

/** detik -> frame, selalu dibulatkan */
export const sec2f = (s: number) => Math.max(0, Math.round(s * FPS));

const startOf = (text: string) => {
  const w = captions.find((c) => c.text === text);
  if (!w) throw new Error(`Kata "${text}" tidak ada di captions.ts`);
  return w.start + AUDIO_OFFSET;
};

/** Kata pertama yang membuka tiap beat 2..7 (diambil dari data caption). */
const BEAT_ANCHORS = ["Sekitar", "Untuk", "Seiring", "Awalnya,", "Dan", "Tapi,"];
const BEAT_IDS = ["b1", "b2", "b3", "b4", "b5", "b6", "b7"] as const;

export const lastWordEnd = captions[captions.length - 1].end + AUDIO_OFFSET;
/** kata terakhir + 1 detik */
export const TOTAL_FRAMES = sec2f(lastWordEnd + TAIL_SECONDS);

const starts = [0, ...BEAT_ANCHORS.map((a) => sec2f(startOf(a)))];

export type BeatInfo = {id: (typeof BEAT_IDS)[number]; from: number; duration: number};

export const BEATS: BeatInfo[] = BEAT_IDS.map((id, i) => ({
  id,
  from: starts[i],
  duration: (i + 1 < starts.length ? starts[i + 1] : TOTAL_FRAMES) - starts[i],
}));

/** Frame potongan antar beat (tengah transisi) */
export const CUTS = BEATS.slice(1).map((b) => b.from);

/* ---------- Subtitle: kelompok kata dari captions ---------- */

export type SubWord = {text: string; fromF: number; toF: number};
export type SubChunk = {words: SubWord[]; split: number; fromF: number; toF: number};

const SENTENCE_END = /[.?!]$/;
const MAX_CHARS = 44;
const MAX_WORDS = 6;
const GAP_BREAK = 0.35;

function buildChunks(): SubChunk[] {
  const groups: SubWord[][] = [];
  let cur: SubWord[] = [];
  let chars = 0;
  captions.forEach((c, i) => {
    const w: SubWord = {
      text: c.text,
      fromF: sec2f(c.start + AUDIO_OFFSET),
      toF: sec2f(c.end + AUDIO_OFFSET),
    };
    const prev = captions[i - 1];
    const gap = prev ? c.start - prev.end : 0;
    const wouldBe = chars + (cur.length ? 1 : 0) + c.text.length;
    const prevEnded = cur.length > 0 && SENTENCE_END.test(cur[cur.length - 1].text);
    if (cur.length && (wouldBe > MAX_CHARS || cur.length >= MAX_WORDS || prevEnded || gap > GAP_BREAK)) {
      groups.push(cur);
      cur = [];
      chars = 0;
    }
    chars += (cur.length ? 1 : 0) + c.text.length;
    cur.push(w);
  });
  if (cur.length) groups.push(cur);

  return groups.map((words, gi) => {
    // pecah jadi dua baris seimbang
    let best = 0;
    let bestMax = Infinity;
    for (let k = 0; k < words.length; k++) {
      const l1 = words.slice(0, k).map((w) => w.text).join(" ").length;
      const l2 = words.slice(k).map((w) => w.text).join(" ").length;
      const m = Math.max(l1, l2);
      if (m < bestMax) {
        bestMax = m;
        best = k;
      }
    }
    const fromF = words[0].fromF;
    const lastTo = words[words.length - 1].toF;
    const next = groups[gi + 1];
    const toF = next ? Math.min(next[0].fromF, lastTo + 12) : lastTo + 12;
    return {words, split: best, fromF, toF};
  });
}

export const SUB_CHUNKS = buildChunks();

import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile} from "remotion";
import {BEATS} from "./timeline";
import {Subtitle} from "./components/Subtitle";
import {Transition} from "./components/Transition";
import {Beat1} from "./beats/Beat1";
import {Beat2} from "./beats/Beat2";
import {Beat3} from "./beats/Beat3";
import {Beat4} from "./beats/Beat4";
import {Beat5} from "./beats/Beat5";
import {Beat6} from "./beats/Beat6";
import {Beat7} from "./beats/Beat7";

const BEAT_COMPONENTS = [Beat1, Beat2, Beat3, Beat4, Beat5, Beat6, Beat7];
/** jenis transisi di potongan ke-2..7; B4 -> B5 memakai cahaya lentera */
const TRANSITION_KINDS: ("fog" | "lantern")[] = ["fog", "fog", "fog", "lantern", "fog", "fog"];
const HALF = 15; // transisi 30 frame, potongan tepat di tengah (saat kabut paling pekat)

export const HalloweenVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: "#0d0618"}}>
      <Audio src={staticFile("narasi.mp3")} />

      {BEATS.map((beat, i) => {
        const Comp = BEAT_COMPONENTS[i];
        return (
          <Sequence key={beat.id} from={beat.from} durationInFrames={beat.duration} name={`Beat ${i + 1}`}>
            <Comp />
          </Sequence>
        );
      })}

      {BEATS.slice(1).map((beat, i) => (
        <Sequence
          key={`t-${beat.id}`}
          from={beat.from - HALF}
          durationInFrames={HALF * 2}
          name={`Transisi ${i + 1}-${i + 2}`}
        >
          <Transition kind={TRANSITION_KINDS[i]} />
        </Sequence>
      ))}

      <Subtitle />
    </AbsoluteFill>
  );
};

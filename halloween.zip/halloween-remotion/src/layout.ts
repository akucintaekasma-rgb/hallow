import {Easing, interpolate} from "remotion";
import layout from "./layout.json";

export type Box = {x: number; y: number; w: number; h: number};
type Key = {t: number; box: number[]};
type El = {id: string; t: number[]; keys: Key[]};
type Layout = {beats: Record<string, {duration: number; elements: El[]}>};

const beats = (layout as unknown as Layout).beats;

const find = (beat: string, id: string): El => {
  const el = beats[beat]?.elements.find((e) => e.id === id);
  if (!el) throw new Error(`layout.json: elemen ${beat}.${id} tidak ada`);
  return el;
};

/** Posisi eksplisit elemen pada detik t (relatif ke awal beat), dari layout.json. */
export function boxAt(beat: string, id: string, t: number): Box {
  const el = find(beat, id);
  const ks = el.keys;
  if (ks.length === 1) {
    const [x, y, w, h] = ks[0].box;
    return {x, y, w, h};
  }
  const times = ks.map((k) => k.t);
  const f = (i: number) =>
    interpolate(
      t,
      times,
      ks.map((k) => k.box[i]),
      {
        easing: Easing.inOut(Easing.cubic),
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      },
    );
  return {x: f(0), y: f(1), w: f(2), h: f(3)};
}

export const isActive = (beat: string, id: string, t: number) => {
  const el = find(beat, id);
  return t >= el.t[0] && t <= el.t[1];
};

export const startOfEl = (beat: string, id: string) => find(beat, id).t[0];

/** 0..1, seberapa cepat elemen bergerak horizontal (untuk animasi langkah kaki) */
export function walkAmount(beat: string, id: string, t: number): number {
  const a = boxAt(beat, id, t - 0.1);
  const b = boxAt(beat, id, t + 0.1);
  const speed = Math.abs(b.x - a.x) / 0.2;
  return Math.max(0, Math.min(1, speed / 260));
}
